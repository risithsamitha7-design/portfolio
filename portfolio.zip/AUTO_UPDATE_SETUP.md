# Automatic Portfolio Update Setup

This portfolio automatically updates when you add new projects to GitHub!

## How It Works

The GitHub Actions workflow:
1. **Fetches your GitHub repos** daily (or on every push)
2. **Updates the Projects section** in your portfolio
3. **Commits the changes** automatically
4. **Redeploys** to GitHub Pages

## Setup Instructions

### Step 1: Push Portfolio to GitHub

```bash
cd C:\Users\risit\.openclaw\workspace\portfolio

git init
git add .
git commit -m "Initial portfolio with auto-update"
git remote add origin https://github.com/risithsamitha7-design/portfolio.git
git push -u origin main
```

### Step 2: Enable GitHub Actions

1. Go to your repo on GitHub
2. Click **"Actions"** tab
3. Click **"I understand my workflows, go ahead and enable them"**
4. The workflow will run automatically!

### Step 3: Enable GitHub Pages

1. Go to **Settings** → **Pages**
2. Source: **GitHub Actions**
3. Your site will be at: `https://risithsamitha7-design.github.io/portfolio`

## How Updates Work

### Automatic Updates (Daily)
- Every day at midnight, the workflow runs
- Checks for new repositories
- Updates projects section automatically
- Commits and deploys changes

### Manual Updates (Instant)
- Push any change to trigger workflow
- Or go to Actions → Update Portfolio → Run workflow

### What Gets Updated

✅ **GitHub Projects:**
- New repositories automatically added
- Descriptions synced from GitHub
- Programming languages detected
- Links updated

⚠️ **LinkedIn:**
- LinkedIn doesn't have a public API
- Update manually in `index.html`
- Or use LinkedIn badge/embed

## Workflow Triggers

The workflow runs when:
1. **You push code** to main/master branch
2. **Daily at midnight** (checks for new repos)
3. **Manually** (you click "Run workflow")

## Customization

### Change Update Frequency

Edit `.github/workflows/update-portfolio.yml`:

```yaml
# Daily at midnight (current)
- cron: '0 0 * * *'

# Every hour
- cron: '0 * * * *'

# Every Monday at 9am
- cron: '0 9 * * 1'
```

### Add More Info

The workflow can also fetch:
- GitHub stats (stars, forks)
- Contribution graph
- Repository topics
- Release information

Just modify the Node.js script in the workflow!

## Troubleshooting

### Workflow not running?
- Check Actions tab for errors
- Make sure workflow file is in `.github/workflows/`
- Verify Actions are enabled in Settings

### Changes not showing?
- Wait 1-2 minutes for deployment
- Check GitHub Pages settings
- Clear browser cache

### Wrong repos showing?
- Workflow filters out forks
- Edit the filter in the workflow
- Add specific repo names to exclude

## Security

The workflow uses:
- `GITHUB_TOKEN` (automatically provided)
- No personal tokens needed
- Read-only access to your public repos

## Manual Override

If you want to manually edit projects:

1. Edit `index.html` directly
2. Commit and push
3. Workflow won't overwrite manual changes unless repos change

## Next Steps

1. ✅ Push portfolio to GitHub
2. ✅ Enable Actions
3. ✅ Enable GitHub Pages
4. ✅ Watch it auto-update!

## Example

When you create a new repo called "awesome-project":

1. Within 24 hours (or on next push), workflow runs
2. Fetches "awesome-project" info
3. Adds it to your portfolio
4. Commits changes
5. Redeploys automatically
6. Your portfolio now shows the new project!

**No manual work needed!** 🚀